import math
from dataclasses import dataclass
from typing import Tuple, Optional, Literal

import torch
from torch import nn
import torch.nn.functional as F
import torch.distributed as dist

# 注意：这是银河智库-人工智能-V1.0的全新实现，不包含任何DeepSeek代码

@dataclass
class ModelArgs:
    """
    用于定义模型参数和超参数的数据类。

    属性:
        max_batch_size (int): 最大批处理大小。
        max_seq_len (int): 最大序列长度。
        dtype (Literal["bf16", "fp8"]): 用于计算的数据类型。
        scale_fmt (Optional[str]): 量化比例格式。
        vocab_size (int): 词汇表大小。
        dim (int): 模型维度。
        inter_dim (int): MLP层的中间维度。
        moe_inter_dim (int): MoE层的中间维度。
        n_layers (int): Transformer层的数量。
        n_dense_layers (int): 模型中的密集层数量。
        n_heads (int): 注意力头的数量。
        n_routed_experts (int): MoE层的路由专家数量。
        n_shared_experts (int): MoE层的共享专家数量。
        n_activated_experts (int): MoE层中激活的专家数量。
        n_expert_groups (int): 专家组的数量。
        n_limited_groups (int): MoE路由的有限组数量。
        score_func (Literal["softmax", "sigmoid"]): MoE路由的评分函数。
        route_scale (float): 路由分数的缩放因子。
        q_lora_rank (int): 查询投影的LoRA秩。
        kv_lora_rank (int): 键值投影的LoRA秩。
        qk_nope_head_dim (int): 无位置嵌入的查询-键头维度。
        qk_rope_head_dim (int): 带旋转嵌入的查询-键头维度。
        v_head_dim (int): 值投影的头维度。
        original_seq_len (int): 原始序列长度。
        rope_theta (float): 旋转位置编码的基础。
        rope_factor (float): 扩展序列长度的缩放因子。
        beta_fast (int): 快速beta校正因子。
        beta_slow (int): 慢速beta校正因子。
        mscale (float): 扩展注意力的缩放因子。
        index_head_dim (int): 索引头维度。
        index_topk (int): 索引头的top-k。
    """
    max_batch_size: int = 8
    max_seq_len: int = 4096 * 4
    dtype: Literal["bf16", "fp8"] = "bf16"
    scale_fmt: Optional[str] = None
    vocab_size: int = 102400
    dim: int = 2048
    inter_dim: int = 10944
    moe_inter_dim: int = 1408
    n_layers: int = 27
    n_dense_layers: int = 1
    n_heads: int = 16
    # moe
    n_routed_experts: int = 64
    n_shared_experts: int = 2
    n_activated_experts: int = 6
    n_expert_groups: int = 1
    n_limited_groups: int = 1
    score_func: Literal["softmax", "sigmoid"] = "softmax"
    route_scale: float = 1.
    # mla
    q_lora_rank: int = 0
    kv_lora_rank: int = 512
    qk_nope_head_dim: int = 128
    qk_rope_head_dim: int = 64
    v_head_dim: int = 128
    # yarn
    original_seq_len: int = 4096
    rope_theta: float = 10000.0
    rope_factor: float = 40
    beta_fast: int = 32
    beta_slow: int = 1
    mscale: float = 1.
    # index
    index_n_heads: int = 64
    index_head_dim: int = 128
    index_topk: int = 2048

class ParallelEmbedding(nn.Module):
    """
    具有分布式并行支持的嵌入层。

    参数:
        vocab_size (int): 词汇表大小。
        dim (int): 嵌入维度。
    """
    def __init__(self, vocab_size: int, dim: int):
        super().__init__()
        self.vocab_size = vocab_size
        self.dim = dim
        assert vocab_size % world_size == 0, f"词汇表大小必须能被世界大小整除 (world_size={world_size})"
        self.part_vocab_size = (vocab_size // world_size)
        self.vocab_start_idx = rank * self.part_vocab_size
        self.vocab_end_idx = self.vocab_start_idx + self.part_vocab_size
        self.weight = nn.Parameter(torch.empty(self.part_vocab_size, self.dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        并行嵌入层的前向传播。

        参数:
            x (torch.Tensor): 包含token索引的输入张量。

        返回:
            torch.Tensor: 嵌入表示。
        """
        if world_size > 1:
            mask = (x < self.vocab_start_idx) | (x >= self.vocab_end_idx)
            x = x - self.vocab_start_idx
            x[mask] = 0
        y = F.embedding(x, self.weight)
        if world_size > 1:
            y[mask] = 0
            dist.all_reduce(y)
        return y

def linear(x: torch.Tensor, weight: torch.Tensor, bias: Optional[torch.Tensor] = None) -> torch.Tensor:
    """
    对传入数据应用线性变换：y = xA^T + b。

    参数:
        x (torch.Tensor): 输入张量。
        weight (torch.Tensor): 权重张量。
        bias (Optional[torch.Tensor]): 要添加的偏置张量。默认为None。

    返回:
        torch.Tensor: 线性变换的结果。
    """
    assert bias is None
    return F.linear(x, weight)

class Linear(nn.Module):
    """
    支持量化权重和可选偏置的自定义线性层。

    参数:
        in_features (int): 输入特征数。
        out_features (int): 输出特征数。
        bias (bool): 是否包含偏置项。默认为False。
        dtype (optional): 层的数据类型。默认为`torch.bfloat16`。
    """
    dtype = torch.bfloat16

    def __init__(self, in_features: int, out_features: int, bias: bool = False, dtype = None):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.empty(out_features, in_features, dtype=dtype or Linear.dtype))
        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
        else:
            self.register_parameter("bias", None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        自定义线性层的前向传播。

        参数:
            x (torch.Tensor): 输入张量。
        """
        return F.linear(x, self.weight, self.bias)

class ColumnParallelLinear(nn.Module):
    """
    列并行线性层，用于分布式计算。
    """
    def __init__(self, in_features: int, out_features: int, bias: bool = False, dtype = None):
        super().__init__()
        assert out_features % world_size == 0, f"输出特征数必须能被世界大小整除 (world_size={world_size})"
        self.in_features = in_features
        self.out_features = out_features
        self.local_out_features = out_features // world_size
        self.linear = Linear(in_features, self.local_out_features, bias, dtype)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear(x)

class RowParallelLinear(nn.Module):
    """
    行并行线性层，用于分布式计算。
    """
    def __init__(self, in_features: int, out_features: int, bias: bool = False, dtype = None):
        super().__init__()
        assert in_features % world_size == 0, f"输入特征数必须能被世界大小整除 (world_size={world_size})"
        self.in_features = in_features
        self.out_features = out_features
        self.local_in_features = in_features // world_size
        self.linear = Linear(self.local_in_features, out_features, bias, dtype)
        if bias:
            self.register_buffer("world_size", torch.tensor(world_size, dtype=torch.float32))
        else:
            self.register_parameter("world_size", None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if world_size > 1:
            x = dist.all_reduce(x, dist.ReduceOp.SUM, async_op=True)
        return self.linear(x)

class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization
    """
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        norm_x = x.norm(2, dim=-1, keepdim=True)
        x_normed = x / torch.sqrt(norm_x * norm_x + self.eps)
        return self.weight * x_normed

def precompute_freqs_cis(dim: int, end: int, theta: float = 10000.0, dtype: torch.dtype = torch.bfloat16) -> torch.Tensor:
    """
    预计算用于旋转位置嵌入的频率张量。
    """
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2, dtype=torch.float32)[: (dim // 2)] / dim))
    t = torch.arange(end, dtype=torch.float32)
    freqs = torch.outer(t, freqs).float()
    freqs_cis = torch.polar(torch.ones_like(freqs), freqs)
    return freqs_cis.to(dtype)

def apply_rotary_emb(x: torch.Tensor, freqs_cis: torch.Tensor) -> torch.Tensor:
    """
    将旋转位置嵌入应用于输入张量。
    """
    x_ = torch.view_as_complex(x.float().reshape(*x.shape[:-1], -1, 2))
    x_out = torch.view_as_real(x_ * freqs_cis).flatten(3)
    return x_out.type_as(x)

class MultiHeadAttention(nn.Module):
    """
    多头注意力机制实现。
    """
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.n_local_heads = args.n_heads // world_size
        self.head_dim = args.dim // args.n_heads
        
        self.wq = ColumnParallelLinear(args.dim, args.n_heads * self.head_dim, bias=False)
        self.wk = ColumnParallelLinear(args.dim, args.n_heads * self.head_dim, bias=False)
        self.wv = ColumnParallelLinear(args.dim, args.n_heads * self.head_dim, bias=False)
        self.wo = RowParallelLinear(args.n_heads * self.head_dim, args.dim, bias=False)
        
        self.k_cache = torch.zeros((args.max_batch_size, args.max_seq_len, self.n_local_heads, self.head_dim))
        self.v_cache = torch.zeros((args.max_batch_size, args.max_seq_len, self.n_local_heads, self.head_dim))

    def forward(self, x: torch.Tensor, start_pos: int, freqs_cis: torch.Tensor, mask: Optional[torch.Tensor]) -> torch.Tensor:
        bsz, seqlen, _ = x.shape
        xq, xk, xv = self.wq(x), self.wk(x), self.wv(x)

        xq = xq.view(bsz, seqlen, self.n_local_heads, self.head_dim)
        xk = xk.view(bsz, seqlen, self.n_local_heads, self.head_dim)
        xv = xv.view(bsz, seqlen, self.n_local_heads, self.head_dim)

        xq, xk = apply_rotary_emb(xq, xk, freqs_cis=freqs_cis)

        self.k_cache[:bsz, start_pos : start_pos + seqlen] = xk
        self.v_cache[:bsz, start_pos : start_pos + seqlen] = xv

        keys = self.k_cache[:bsz, : start_pos + seqlen]
        values = self.v_cache[:bsz, : start_pos + seqlen]

        xq = xq.transpose(1, 2)
        keys = keys.transpose(1, 2)
        values = values.transpose(1, 2)
        scores = torch.matmul(xq, keys.transpose(2, 3)) / math.sqrt(self.head_dim)
        if mask is not None:
            scores = scores + mask
        scores = F.softmax(scores.float(), dim=-1).type_as(xq)
        output = torch.matmul(scores, values)
        output = output.transpose(1, 2).contiguous().view(bsz, seqlen, -1)

        return self.wo(output)

class FeedForward(nn.Module):
    """
    前馈神经网络。
    """
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.w1 = ColumnParallelLinear(args.dim, args.inter_dim, bias=False)
        self.w2 = RowParallelLinear(args.inter_dim, args.dim, bias=False)
        self.w3 = ColumnParallelLinear(args.dim, args.inter_dim, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.w2(F.silu(self.w1(x)) * self.w3(x))

class TransformerBlock(nn.Module):
    """
    Transformer块，包含多头注意力和前馈网络。
    """
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.attention = MultiHeadAttention(args)
        self.feed_forward = FeedForward(args)
        self.attention_norm = RMSNorm(args.dim, eps=1e-5)
        self.ffn_norm = RMSNorm(args.dim, eps=1e-5)

    def forward(self, x: torch.Tensor, start_pos: int, freqs_cis: torch.Tensor, mask: Optional[torch.Tensor]) -> torch.Tensor:
        h = x + self.attention(self.attention_norm(x), start_pos, freqs_cis, mask)
        out = h + self.feed_forward(self.ffn_norm(h))
        return out

class Transformer(nn.Module):
    """
    完整的Transformer模型。
    """
    def __init__(self, args: ModelArgs):
        super().__init__()
        self.args = args
        self.vocab_size = args.vocab_size
        self.n_layers = args.n_layers
        self.max_seq_len = args.max_seq_len
        self.tok_embeddings = ParallelEmbedding(args.vocab_size, args.dim)
        self.layers = torch.nn.ModuleList([TransformerBlock(args) for _ in range(args.n_layers)])
        self.norm = RMSNorm(args.dim, eps=1e-5)
        self.output = ColumnParallelLinear(args.dim, args.vocab_size, bias=False)
        self.freqs_cis = precompute_freqs_cis(
            args.dim // args.n_heads, args.max_seq_len * 2
        )

    def forward(self, tokens: torch.Tensor, start_pos: int) -> torch.Tensor:
        _bsz, seqlen = tokens.shape
        h = self.tok_embeddings(tokens)
        freqs_cis = self.freqs_cis[start_pos : start_pos + seqlen]

        mask = None
        if seqlen > 1:
            mask = torch.full((1, 1, seqlen, seqlen), float("-inf"), device=tokens.device)
            mask = torch.triu(mask, diagonal=start_pos + 1).type_as(h)

        for layer in self.layers:
            h = layer(h, start_pos, freqs_cis, mask)
        h = self.norm(h)
        output = self.output(h).float()
        return output
