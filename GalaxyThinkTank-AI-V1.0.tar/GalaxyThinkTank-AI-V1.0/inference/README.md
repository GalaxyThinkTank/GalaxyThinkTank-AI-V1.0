# 银河智库-人工智能-V1.0

首先将huggingface模型权重转换为推理演示所需的格式。将 `MP` 设置为匹配您的可用GPU数量：
```bash
cd inference
export EXPERTS=192
python convert.py --hf-ckpt-path ${HF_CKPT_PATH} --save-path ${SAVE_PATH} --n-experts ${EXPERTS} --model-parallel ${MP}
```

启动交互式聊天界面并开始探索银河智库的能力：
```bash
export CONFIG=config_150B_gt_v10.json
torchrun --nproc-per-node ${MP} generate.py --ckpt-path ${SAVE_PATH} --config ${CONFIG} --interactive
```
