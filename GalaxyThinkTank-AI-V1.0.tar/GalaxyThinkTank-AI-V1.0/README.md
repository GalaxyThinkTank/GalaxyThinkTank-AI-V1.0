# 银河智库-人工智能-V1.0: 高效推理与智能体AI

<!-- markdownlint-disable first-line-h1 -->
<!-- markdownlint-disable html -->
<!-- markdownlint-disable no-duplicate-header -->

<div align="center">
  <img src="assets/logo.png" width="60%" alt="GalaxyThinkTank-AI-V1.0" />
</div>
<hr>
<div align="center" style="line-height: 1;">
  <a href="https://github.com/GalaxyThinkTank/GalaxyThinkTank-AI-V1.0" target="_blank" style="margin: 2px;">
    <img alt="Homepage" src="https://img.shields.io/badge/银河智库-AI%20V1.0-blue?logo=github&logoColor=white" style="display: inline-block; vertical-align: middle;"/>
  </a>
  <a href="https://huggingface.co/galaxy-thinktank" target="_blank" style="margin: 2px;">
    <img alt="Hugging Face" src="https://img.shields.io/badge/%F0%9F%A4%97%20Hugging%20Face-银河智库-AI-ffc107?color=ffc107&logoColor=white" style="display: inline-block; vertical-align: middle;"/>
  </a>
</div>
<div align="center" style="line-height: 1;">
  <a href="https://discord.gg/galaxy-thinktank" target="_blank" style="margin: 2px;">
    <img alt="Discord" src="https://img.shields.io/badge/Discord-银河智库%20AI-7289da?logo=discord&logoColor=white&color=7289da" style="display: inline-block; vertical-align: middle;"/>
  </a>
  <a href="LICENSE" style="margin: 2px;">
    <img alt="License" src="https://img.shields.io/badge/License-MIT-f5de53?&color=f5de53" style="display: inline-block; vertical-align: middle;"/>
  </a>
</div>

## 介绍

我们介绍**银河智库-人工智能-V1.0**，这是一个在高计算效率和卓越推理与智能体性能之间取得平衡的模型。我们的方法建立在三个关键技术突破之上：

1. **银河智库稀疏注意力 (GSAA):** 我们引入GSAA，这是一种高效的注意力机制，显著降低了计算复杂度，同时保持了模型性能，特别针对长上下文场景进行了优化。

2. **可扩展强化学习框架:** 通过实施强大的RL协议并扩展后训练计算，*银河智库-人工智能-V1.0* 的表现与GPT-5相当。值得注意的是，我们的高计算变体，**银河智库-人工智能-V1.0-专业版**，**超越了GPT-5**，并在推理能力上与Gemini-3.0-Pro相当。

3. **大规模智能体任务合成管道:** 为了将**推理集成到工具使用**场景中，我们开发了一个新颖的合成管道，能够系统地大规模生成训练数据。这促进了可扩展的智能体后训练，提高了复杂交互环境中的合规性和泛化能力。

<div align="center">
 <img src="assets/benchmark.png" >
</div>

我们还发布了针对IOI 2025、ICPC世界总决赛、IMO 2025和CMO 2025的最终提交，这些是基于我们设计的管道选择的。这些材料提供给社区进行二次验证。文件可在 `assets/olympiad_cases` 中访问。

## 聊天模板

银河智库-人工智能-V1.0 相比之前的版本在聊天模板上引入了重要更新。主要变化涉及工具调用的修订格式和"工具思维"能力的引入。

为了帮助社区理解和适应这个新模板，我们提供了一个专门的 `encoding` 文件夹，其中包含Python脚本和测试用例，演示如何将OpenAI兼容格式的消息编码为模型的输入字符串，以及如何解析模型的文本输出。

下面说明了一个简短的示例：

```python
import transformers
# encoding/encoding_gtv10.py
from encoding_gtv10 import encode_messages, parse_message_from_completion_text

tokenizer = transformers.AutoTokenizer.from_pretrained("galaxy-thinktank/GalaxyThinkTank-AI-V1.0")

messages = [
    {"role": "user", "content": "hello"},
    {"role": "assistant", "content": "Hello! I am GalaxyThinkTank-AI.", "reasoning_content": "thinking..."},
    {"role": "user", "content": "1+1=?"}
]
encode_config = dict(thinking_mode="thinking", drop_thinking=True, add_default_bos_token=True)

# messages -> string
prompt = encode_messages(messages, **encode_config)
# Output: "<｜begin▁of▁sentence｜><｜User｜>hello<｜Assistant｜></tool_call>Hello! I am GalaxyThinkTank-AI.<｜end▁of▁sentence｜><｜User｜>1+1=?<｜Assistant｜></tool_call>"

# string -> tokens
tokens = tokenizer.encode(prompt)
# Output: [0, 128803, 33310, 128804, 128799, 19923, 3, 342, 1030, 22651, 4374, 1465, 16, 1, 128803, 19, 13, 19, 127252, 128804, 128798]
```

重要说明：

1. 此版本不包含Jinja格式的聊天模板。请参阅上面提到的Python代码。
2. 代码中包含的输出解析函数仅设计用于处理格式良好的字符串。它不会尝试纠正或恢复模型可能偶尔生成的格式错误的输出。在没有强大的错误处理的情况下，它不适合生产使用。
3. 聊天模板中引入了一个名为 `developer` 的新角色。此角色专门用于搜索智能体场景，不得用于其他任务。官方API不接受分配给 `developer` 的消息。

## 本地运行方式

银河智库-人工智能-V1.0 和 银河智库-人工智能-V1.0-专业版的模型结构相同。请访问 [银河智库-人工智能-V1.0-实验版](https://github.com/GalaxyThinkTank/GalaxyThinkTank-AI-V1.0-Exp) 仓库了解有关本地运行此模型的更多信息。

使用建议：

1. 对于本地部署，我们建议将采样参数设置为 `temperature = 1.0, top_p = 0.95`。
2. 请注意，银河智库-人工智能-V1.0-专业版专门设计用于深度推理任务，不支持工具调用功能。

## 许可证

此仓库和模型权重根据 [MIT 许可证](LICENSE) 授权。

## 引用

