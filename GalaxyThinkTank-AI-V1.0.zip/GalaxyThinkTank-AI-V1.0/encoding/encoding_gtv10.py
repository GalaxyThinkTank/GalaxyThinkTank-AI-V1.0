from typing import Any, Dict, List, Union, Optional, Tuple
import copy
import json
import re

TOOLS_SYSTEM_TEMPLATE = """## 工具

您可以使用一组工具来回答用户的问题。
您可以通过在回复中写入一个 "<{gtml_token}function_calls>" 块来调用函数，格式如下：
<{gtml_token}function_calls>
<{gtml_token}invoke name="$FUNCTION_NAME">
<{gtml_token}parameter name="$PARAMETER_NAME" string="true|false">$PARAMETER_VALUE</{gtml_token}parameter>
...
</{gtml_token}invoke>
<{gtml_token}invoke name="$FUNCTION_NAME2">
...
</{gtml_token}invoke>
</{gtml_token}function_calls>

字符串和标量参数应按原样指定，无需任何转义或引号，而列表和对象应使用JSON格式。"string"属性应设置为"true"表示字符串类型参数，"false"表示其他类型（数字、布尔值、数组、对象）。

如果启用了thinking_mode，则在函数结果之后，您应强烈考虑输出一个思维块。以下是示例：

<{gtml_token}function_calls>
...
</{gtml_token}function_calls>

<function_results>
...
</function_results>

{thinking_start_token}...思考结果{thinking_end_token}

以下是JSONSchema格式的可用函数：
<functions>
{tool_schemas}
</functions>
"""

bos_token: str = "<｜begin▁of▁sentence｜>"
eos_token: str = "<｜end▁of▁sentence｜>"
thinking_start_token: str = "</tool_call>"
thinking_end_token: str = "</tool_call>"
gtml_token: str = "｜GTML｜"  # GalaxyThinkTank Markup Language
system_msg_template: str = "{content}"
user_msg_template: str = "<｜User｜>{content}<｜Assistant｜>"
assistant_msg_template: str = "{reasoning}{content}{tool_calls}<｜end▁of▁sentence｜>"
thinking_template = "{reasoning_content}"

response_format_template: str = (
    "## 响应格式：\n\n您必须严格遵守以下模式进行回复：\n{schema}"
)
tool_call_template: str = (
    "<{gtml_token}invoke name=\"{name}\">\n{arguments}\n</{gtml_token}invoke>"
)
tool_calls_template: str = (
    "<{gtml_token}function_calls>\n{tool_calls}\n</{gtml_token}function_calls>"
)

tool_output_template: str = (
    "\n<result>{content}</result>"
)

def to_json(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False)
    except:
        return json.dumps(value, ensure_ascii=True)

def tools_from_openai_format(tools):
    return [tool["function"] for tool in tools]

def tool_calls_from_openai_format(tool_calls):
    return [
        {
            "name": tool_call["function"]["name"],
            "arguments": tool_call["function"]["arguments"],
        }
        for tool_call in tool_calls
    ]

def tool_calls_to_openai_format(tool_calls):
    return [
        {
            "type": "function",
            "function": {
                "name": tool_call["name"],
                "arguments": tool_call["arguments"],
            }
        }
        for tool_call in tool_calls
    ]

def encode_arguments_to_gtml(tool_call: Dict[str, str]) -> str:
    p_gtml_template = """<{gtml_token}parameter name="{key}" string="{is_str}">{value}</{gtml_token}parameter>"""
    P_gtml_strs = []

    arguments = json.loads(tool_call["arguments"])

    for k, v in arguments.items():
        p_gtml_str = p_gtml_template.format(
            gtml_token=gtml_token,
            key=k,
            is_str="true" if isinstance(v, str) else "false",
            value=v if isinstance(v, str) else to_json(v),
        )

        P_gtml_strs.append(p_gtml_str)

    return "\n".join(P_gtml_strs)


def decode_gtml_to_arguments(tool_name: str, tool_args: Dict[str, Tuple[str, str]]) -> Dict[str, str]:
    def _decode_value(key: str, value: str, string: str):
        if string == "true":
            value = to_json(value)
        return f"{to_json(key)}: {value}"

    tool_args_json = "{" + ", ".join([_decode_value(k, v, string=is_str) for k, (v, is_str) in tool_args.items()]) + "}"
    return dict(name=tool_name, arguments=tool_args_json)

def render_tools(tools: List[Dict[str, Union[str, Dict[str, Any]]]]) -> str:
    tools_json = [to_json(t) for t in tools]

    return TOOLS_SYSTEM_TEMPLATE.format(
        tool_schemas="\n".join(tools_json),
        gtml_token=gtml_token,
        thinking_start_token=thinking_start_token,
        thinking_end_token=thinking_end_token,
    )

def find_last_user_index(messages: List[Dict[str, Any]]) -> int:
    last_user_index = -1
    for idx in range(len(messages)-1, -1, -1):
        if messages[idx].get("role") in ["user", "developer"]:
            last_user_index = idx
            break
    return last_user_index

def render_message(index: int, messages: List[Dict[str, Any]], thinking_mode: str) -> str:
    assert 0 <= index < len(messages)
    assert thinking_mode in ["chat", "thinking"], f"无效的thinking_mode `{thinking_mode}`"

    prompt = ""
    msg = messages[index]
    last_user_idx = find_last_user_index(messages)

    role = msg.get("role")
    content = msg.get("content")
    tools = msg.get("tools")
    response_format = msg.get("response_format")
    tool_calls = msg.get("tool_calls")
    reasoning_content = msg.get("reasoning_content")

    if tools:
        tools = tools_from_openai_format(tools)
    if tool_calls:
        tool_calls = tool_calls_from_openai_format(tool_calls)

    if role == "system":
        prompt += system_msg_template.format(content=content or "")
        if tools:
            prompt += "\n\n" + render_tools(tools)

        if response_format:
            prompt += "\n\n" + response_format_template.format(schema=to_json(response_format))

    elif role == "developer":
        assert content, f"无效的角色 `{role}` 消息: {msg}"
        content_developer = ""
        if tools:
            content_developer += "\n\n" + render_tools(tools)

        if response_format:
            content_developer += "\n\n" + response_format_template.format(schema=to_json(response_format))

        content_developer += "\n\n# 用户的消息是: {}".format(content)

        prompt += user_msg_template.format(content=content_developer)
        if index == last_user_idx and thinking_mode == "thinking":
            prompt += thinking_start_token
        else:
            prompt += thinking_end_token

    elif role == "user":
        prompt += user_msg_template.format(content=content)

        if index == last_user_idx and thinking_mode == "thinking":
            prompt += thinking_start_token
        else:
            prompt += thinking_end_token

    elif role == "tool":
        prev_assistant_idx = index - 1
        assistant_msg = messages[prev_assistant_idx]
        while prev_assistant_idx >= 0 and assistant_msg.get("role") == "tool":
            prev_assistant_idx -= 1
            assistant_msg = messages[prev_assistant_idx]

        assert index == 0 or prev_assistant_idx >= 0 and assistant_msg.get("role") == "assistant", f"无效的消息在 {index}:\n{assistant_msg}"

        tool_call_order = index - prev_assistant_idx
        assistant_tool_calls = assistant_msg.get("tool_calls")
        assert assistant_tool_calls and len(assistant_tool_calls) >= tool_call_order, "没有工具调用但找到工具输出"

        if tool_call_order == 1:
            prompt += "\n\n<function_results>"

        prompt += tool_output_template.format(content=content)

        if tool_call_order == len(assistant_tool_calls):
            prompt += "\n</function_results>"

            if index >= last_user_idx and thinking_mode == "thinking":
                prompt += "\n\n" + thinking_start_token
            else:
                prompt += "\n\n" + thinking_end_token

    elif role == "assistant":
        prev_assistant_idx = index
        thinking_part = ""

        tool_calls_content = ""
        if tool_calls:
            tool_calls = [
                tool_call_template.format(
                    gtml_token=gtml_token,
                    name=tool_call.get("name"),
                    arguments=encode_arguments_to_gtml(tool_call)
                )
                for tool_call in tool_calls
            ]
            tool_calls_content += "\n\n" + tool_calls_template.format(
                gtml_token=gtml_token,
                tool_calls="\n".join(tool_calls)
            )

        summary_content = content or ""

        if thinking_mode == "thinking" and index > last_user_idx:
            assert reasoning_content or tool_calls, f"ThinkingMode: {thinking_mode}, 在最后用户消息后无效的消息没有reasoning_content/tool_calls `{msg}`"
            thinking_part = thinking_template.format(reasoning_content=reasoning_content or "") + thinking_end_token

        prompt += assistant_msg_template.format(
            reasoning=thinking_part,
            content=summary_content,
            tool_calls=tool_calls_content,
        )
    else:
        raise NotImplementedError(f"未知角色: {role}")

    return prompt

def drop_thinking_messages(messages: List[Dict[str, Any]], last_user_idx: Optional[int]=None) -> List[Dict[str, Any]]:
    messages_wo_thinking: List[Dict[str, Any]] = []
    last_user_idx = find_last_user_index(messages) if last_user_idx is None else last_user_idx
    for idx, msg in enumerate(messages):
        role = msg.get("role")
        if role in ["user", "system", "tool"] or idx >= last_user_idx:
            messages_wo_thinking.append(msg)
            continue

        elif role == "assistant":
            msg_wo_thinking = copy.copy(msg)
            msg_wo_thinking.pop("reasoning_content", None)
            messages_wo_thinking.append(msg_wo_thinking)

    return messages_wo_thinking

def encode_messages(messages: List[Dict[str, Any]], thinking_mode: str, context: Optional[List[Dict[str, Any]]] = None, drop_thinking: bool = True, add_default_bos_token: bool = True) -> str:
    context = context if context else []
    full_messages = context + messages

    prompt = bos_token if add_default_bos_token and len(context) == 0 else ""

    if thinking_mode == "thinking" and drop_thinking:
        full_messages = drop_thinking_messages(full_messages)

    for idx in range(len(messages)):
        prompt += render_message(idx + len(context), full_messages, thinking_mode=thinking_mode)

    return prompt

def _read_until_stop(index: int, text: str, stop: List[str]) -> Tuple[int, str, Optional[str]]:
    min_pos = len(text)
    matched_stop = None
    
    for s in stop:
        pos = text.find(s, index)
        if pos != -1 and pos < min_pos:
            min_pos = pos
            matched_stop = s
    
    if matched_stop:
        content = text[index:min_pos]
        return min_pos + len(matched_stop), content, matched_stop
    else:
        content = text[index:]
        return len(text), content, None

def parse_tool_calls(index: int, text: str):
    tool_calls: List[Dict[str, Any]] = []
    stop_token = None
    tool_calls_end_token = f"</{gtml_token}function_calls>"

    while index < len(text):
        index, _, stop_token = _read_until_stop(index, text, [f"<{gtml_token}invoke", tool_calls_end_token])
        assert _ == ">\n", "工具调用格式错误"

        if stop_token == tool_calls_end_token:
            break

        assert stop_token is not None, "缺少特殊标记"

        index, tool_name_content, stop_token = _read_until_stop(index, text, [f"<{gtml_token}parameter", f"</{gtml_token}invoke>"])

        p_tool_name = re.findall(r'^\s*name="(.*?)">\n$', tool_name_content, flags=re.DOTALL)
        assert len(p_tool_name) == 1, "工具名称格式错误"
        tool_name = p_tool_name[0]

        tool_args: Dict[str, Tuple[str, str]] = {}
        while stop_token == f"<{gtml_token}parameter":
            index, param_content, stop_token = _read_until_stop(index, text, [f"/{gtml_token}parameter"])

            param_kv = re.findall(r'^ name="(.*?)" string="(true|false)">(.*?)<$', param_content, flags=re.DOTALL)
            assert len(param_kv) == 1, "参数格式错误"
            param_name, string, param_value = param_kv[0]

            assert param_name not in tool_args, "重复参数名"
            tool_args[param_name] = (param_value, string)

            index, content, stop_token = _read_until_stop(index, text, [f"<{gtml_token}parameter", f"</{gtml_token}invoke"])
            assert content == ">\n", "参数格式错误"

        tool_call = decode_gtml_to_arguments(tool_name=tool_name, tool_args=tool_args)
        tool_calls.append(tool_call)

    return index, stop_token, tool_calls

# 注意：此函数仅设计用于解析格式正确的字符串，不会尝试纠正模型可能生成的格式错误的输出。
def parse_message_from_completion_text(text: str, thinking_mode: str):
    summary_content, reasoning_content, tool_calls = "", "", []
    index, stop_token = 0, None
    tool_calls_start_token = f"\n\n<{gtml_token}function_calls"

    is_thinking, is_tool_calling = thinking_mode == "thinking", False

    if is_thinking:
        index, content_delta, stop_token = _read_until_stop(index, text, [thinking_end_token, tool_calls_start_token])
        reasoning_content = content_delta
        assert stop_token == thinking_end_token, "无效的思维格式"

    index, content_delta, stop_token = _read_until_stop(index, text, [eos_token, tool_calls_start_token])
    summary_content = content_delta
    if stop_token == tool_calls_start_token:
        is_tool_calling = True
    else:
        assert stop_token == eos_token, "无效的摘要格式"

    if is_tool_calling:
        index, stop_token, tool_calls = parse_tool_calls(index, text)

        index, tool_ends_text, stop_token = _read_until_stop(index, text, [eos_token])
        assert not tool_ends_text, "工具调用后有意外内容"

    assert len(text) == index and stop_token in [eos_token, None], "结尾有意外内容"

    for sp_token in [bos_token, eos_token, thinking_start_token, thinking_end_token, gtml_token]:
        assert sp_token not in summary_content and sp_token not in reasoning_content, "内容中出现意外的特殊标记"

    return {
        "role": "assistant",
        "content": summary_content,
        "reasoning_content": reasoning_content,
        "tool_calls": tool_calls_to_openai_format(tool_calls)
    }
